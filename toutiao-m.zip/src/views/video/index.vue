<template>
  <div class="video-container">视频</div>
</template>

<script>
export default {
  name: 'VideoPage',
  data () {
    return {}
  },
  methods: {}
}
</script>

<style scoped></style>
