<template>
  <div class="qa-container">问答</div>
</template>

<script>
export default {
  name: 'QaPage',
  data () {
    return {}
  },
  methods: {}
}
</script>

<style scoped></style>
